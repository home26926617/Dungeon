public class Hallucinate extends ItemAction{
    public Hallucinate(Creature owner){
        // super(owner);
        System.out.println("hallucinate");
        
    }
}