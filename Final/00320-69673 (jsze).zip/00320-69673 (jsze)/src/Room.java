public class Room extends Structure{
    public Room(){
        
    }

    public void setID(int num){
        System.out.println("set ID: " + num);
        
    }

    public void setCreature(Creature monster){
        System.out.println("set creature: " + monster);
        
    }
}