public class Remove extends CreatureAction{
    public Remove(String name, Creature owner){
        System.out.println("remove");
        
    }
}