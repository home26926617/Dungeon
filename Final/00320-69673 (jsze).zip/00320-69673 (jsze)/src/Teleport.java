public class Teleport extends CreatureAction{
    public Teleport(String name, Creature owner){
        System.out.println("teleport");
        
    }
}