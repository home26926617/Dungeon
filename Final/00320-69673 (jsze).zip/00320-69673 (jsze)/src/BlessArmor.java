public class BlessArmor extends ItemAction{
    public BlessArmor(Item owner){
        // super(owner);
        System.out.println("bless armor");
        
    }
}