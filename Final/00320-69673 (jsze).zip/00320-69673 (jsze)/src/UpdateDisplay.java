public class UpdateDisplay extends CreatureAction{
    public UpdateDisplay(String name, Creature owner){
        System.out.println("update display");
        
    }
}