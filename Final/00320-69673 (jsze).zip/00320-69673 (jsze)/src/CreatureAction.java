public class CreatureAction extends Action{
    public CreatureAction(){
        
    }
}