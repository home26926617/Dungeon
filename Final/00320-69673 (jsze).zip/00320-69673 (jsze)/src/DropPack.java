public class DropPack extends CreatureAction{
    public DropPack(String name, Creature owner){
        System.out.println("drop pack");
        
    }
}