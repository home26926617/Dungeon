public class EndGame extends CreatureAction{
    public EndGame(String name, Creature owner){
        System.out.println("end game");
        
    }
}