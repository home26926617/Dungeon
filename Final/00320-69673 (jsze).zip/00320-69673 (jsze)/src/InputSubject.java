public interface InputSubject {

    void registerInputObserver(InputObserver observer);
}
