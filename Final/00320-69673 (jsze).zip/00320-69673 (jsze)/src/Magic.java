public class Magic extends Displayable{
    
}