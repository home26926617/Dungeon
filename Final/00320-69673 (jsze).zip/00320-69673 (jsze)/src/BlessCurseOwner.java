public class BlessCurseOwner extends ItemAction{
    public BlessCurseOwner(Creature owner){
        // super(owner);
        System.out.println("bless curse owner");
        
    }
}